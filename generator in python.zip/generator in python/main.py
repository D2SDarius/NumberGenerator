import random

a = random.randint(1,10)
b = random.randint(1,100)
c = random.randint(1,1000)
d = random.randint(1,10000)
e = random.randint(1,100000)
f = random.randint(1,1000000)
g = random.randint(1,10000000)
h = random.randint(1,100000000)

file = open("Numbers.txt", "w")
file.write(" " + str(a) + " " + str(b) + " " + str(c) + " " + str(d) + " " + str(e) + " " + str(f) + " " + str(g) + " " + str(h))

print("a " + str(a))
print("b " + str(b))
print("c " + str(c))
print("d " + str(d))
print("e " + str(e))
print("f " + str(f))
print("g " + str(g))
print("h " + str(h))